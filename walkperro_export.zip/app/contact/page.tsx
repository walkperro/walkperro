"use client";

import { useState } from "react";
import Link from "next/link";

export default function ContactPage() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [ok, setOk] = useState<null | boolean>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setOk(null);
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, message }),
      });
      setOk(res.ok);
      if (res.ok) {
        setName(""); setEmail(""); setMessage("");
      }
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen bg-slate-50 text-slate-900">
      <div className="mx-auto max-w-3xl px-4 pb-24 pt-10 sm:px-6 lg:px-0">
        <header className="mb-6 flex items-center justify-between">
          <Link href="/" className="text-sm text-slate-500 hover:text-slate-900">← Back home</Link>
          <span className="text-xs font-semibold tracking-[0.22em] text-slate-400 uppercase">Work with me</span>
        </header>

        <h1 className="text-4xl font-semibold tracking-tight">Work with me</h1>
        <p className="mt-3 max-w-2xl text-[15px] leading-relaxed text-slate-600">
          Tell me what you’re building and the outcome you want. I’ll reply with a tight plan.
        </p>

        <div className="mt-8 rounded-2xl border border-slate-200 bg-white shadow-sm">
          <form onSubmit={submit} className="p-6 sm:p-8 space-y-5">
            <div className="grid gap-4">
              <label className="text-sm font-medium text-slate-700">Name</label>
              <input
                className="w-full rounded-xl border border-slate-200 bg-slate-100 text-slate-900 placeholder:text-slate-400 px-4 py-3 outline-none focus:ring-4 focus:ring-slate-200"
                placeholder="Your name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
            </div>

            <div className="grid gap-4">
              <label className="text-sm font-medium text-slate-700">Email</label>
              <input
                type="email"
                className="w-full rounded-xl border border-slate-200 bg-slate-100 text-slate-900 placeholder:text-slate-400 px-4 py-3 outline-none focus:ring-4 focus:ring-slate-200"
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>

            <div className="grid gap-4">
              <label className="text-sm font-medium text-slate-700">Project / Message</label>
              <textarea
                rows={6}
                className="w-full rounded-xl border border-slate-200 bg-slate-100 text-slate-900 placeholder:text-slate-400 px-4 py-3 outline-none focus:ring-4 focus:ring-slate-200"
                placeholder="What are we building? What result do you want?"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                required
              />
            </div>

            <div className="flex items-center gap-3">
              <button
                type="submit"
                disabled={loading}
                className="inline-flex items-center justify-center rounded-full bg-emerald-600 px-6 py-3 text-sm font-semibold tracking-[0.15em] text-slate-900 transition hover:bg-emerald-700 disabled:opacity-60"
              >
                {loading ? "Sending…" : "Send"}
              </button>

              {ok === true && (
                <span className="text-sm text-emerald-700">Thanks — talk soon.</span>
              )}
              {ok === false && (
                <span className="text-sm text-rose-700">Couldn’t send. Try again.</span>
              )}
            </div>
          </form>
        </div>

        <div className="mt-6 flex gap-3">
          <a href="https://instagram.com" className="h-10 w-10 grid place-items-center rounded-full border border-slate-200 bg-white shadow-sm text-slate-600 hover:text-slate-900">IG</a>
          <a href="https://tiktok.com" className="h-10 w-10 grid place-items-center rounded-full border border-slate-200 bg-white shadow-sm text-slate-600 hover:text-slate-900">TikTok</a>
        </div>
      </div>
    </main>
  );
}
