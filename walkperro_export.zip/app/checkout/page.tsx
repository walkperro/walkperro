"use client";

import { useEffect, useRef } from "react";
import { useSearchParams } from "next/navigation";
import Script from "next/script";

export default function CheckoutPage() {
  const params = useSearchParams();
  const mountRef = useRef<HTMLDivElement | null>(null);
  const price = params.get("price");
  const qsSecret = params.get("client_secret") || params.get("cs");
  const pk = process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY!;

  // Mount Embedded Checkout after Stripe.js loads
  const onStripeReady = async () => {
    // @ts-ignore – Stripe injected by script tag
    const stripe = (window as any).Stripe(pk);

    const fetchClientSecret = async () => {
      // Prefer existing secret in URL if present (refresh-safe)
      if (qsSecret) return qsSecret;

      // Otherwise create an embedded session for the price
      const r = await fetch(`/api/checkout?price=${encodeURIComponent(price || "")}`);
      const data = await r.json();
      if (!data?.client_secret) throw new Error("Missing client_secret");
      // replace ?price= with ?client_secret= so refresh keeps working
      const url = new URL(window.location.href);
      url.searchParams.delete("price");
      url.searchParams.set("client_secret", data.client_secret);
      history.replaceState({}, "", url.toString());
      return data.client_secret;
    };

    const checkout = await stripe.initEmbeddedCheckout({
      fetchClientSecret,
      // optional:
      // onComplete: () => { /* post-complete hook */ },
    });

    checkout.mount(mountRef.current!);
  };

  // guard: need either a price or a secret
  const ok = Boolean(price || qsSecret);

  return (
    <main className="min-h-screen bg-slate-50 text-slate-900">
      <div className="mx-auto max-w-3xl px-4 py-10">
        {!ok ? (
          <p className="text-sm text-slate-600">Missing price. Start from a product.</p>
        ) : (
          <>
            <Script src="https://js.stripe.com/v3" strategy="afterInteractive" onLoad={onStripeReady} />
            <div id="checkout" ref={mountRef} />
          </>
        )}
      </div>
    </main>
  );
}
