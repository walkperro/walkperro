import type { Metadata } from "next";
import { Inter, Playfair_Display } from "next/font/google";
import "./globals.css";
import ScrollReveal from "@/components/ScrollReveal";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
});

const playfair = Playfair_Display({
  subsets: ["latin"],
  variable: "--font-playfair",
});

export const metadata: Metadata = {
  title: "WalkPerro — Luxury-minimal tools for relentless cashflow",
  description:
    "Digital systems, playbooks and prompt packs for builders, ghosts and quiet killers who move with taste.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <head>
        {/* Payhip overlay script */}
        <script src="https://payhip.com/payhip.js" defer />
      </head>
      <body
        className={`${inter.variable} ${playfair.variable} bg-[#050608] text-slate-100 antialiased`}
      >
        {/* site-wide scroll fade-in */}
        <ScrollReveal />
        <div className="font-sans min-h-dvh bg-[radial-gradient(circle_at_top,_#020617,_#050608_55%,_#02010b_100%)] text-slate-100">
          {children}
        </div>
      </body>
    </html>
  );
}
