import { NextResponse } from "next/server";
import Stripe from "stripe";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);

export async function GET(req: Request) {
  try {
    const url = new URL(req.url);
    const price = url.searchParams.get("price");
    if (!price) return NextResponse.json({ error: "missing_price" }, { status: 400 });

    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      ui_mode: "embedded",
      line_items: [{ price, quantity: 1 }],
      return_url: `${process.env.NEXT_PUBLIC_SITE_URL}/thanks?session_id={CHECKOUT_SESSION_ID}`,
      redirect_on_completion: "if_required",
    });

    return NextResponse.json({ client_secret: session.client_secret });
  } catch (e) {
    console.error("Embedded checkout error:", e);
    return NextResponse.json({ error: "server_error" }, { status: 500 });
  }
}
